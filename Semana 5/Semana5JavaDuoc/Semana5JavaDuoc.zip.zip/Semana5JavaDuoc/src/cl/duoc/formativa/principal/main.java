
package cl.duoc.formativa.principal;

import cl.duoc.formativa.semana5.semana_5;

public class main {
  public static void main(String[] args) {
    new semana_5().ejecutar();
    }  
}

